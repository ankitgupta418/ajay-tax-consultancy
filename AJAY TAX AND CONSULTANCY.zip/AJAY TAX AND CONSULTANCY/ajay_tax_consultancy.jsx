import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Phone, Mail, Building2, FileText, Calculator, CalendarCheck, Users, Sparkles, Star } from "lucide-react";
import { useEffect, useState } from "react";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  show: { opacity: 1, y: 0, transition: { duration: 0.8 } }
};

export default function AjayTaxConsultancy() {
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1600);

    let count = 0;
    const counter = setInterval(() => {
      count += 10;
      setClients(count);
      if (count >= 500) clearInterval(counter);
    }, 30);

    return () => {
      clearTimeout(t);
      clearInterval(counter);
    };
  }, []);

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-black text-white">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold tracking-widest text-green-400">
            AJAY TAX & CONSULTANCY
          </h1>
          <p className="text-gray-400 mt-4">Preparing Premium Experience...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-950 to-black text-white overflow-hidden">

      {/* background glow */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-green-500/20 blur-3xl rounded-full animate-pulse" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-emerald-400/20 blur-3xl rounded-full animate-pulse" />

      {/* NAVBAR */}
      <div className="relative flex justify-between items-center px-10 py-6 border-b border-white/10 backdrop-blur-xl">
        <h1 className="text-2xl font-bold tracking-widest flex items-center gap-2">
          <Sparkles className="text-green-400" /> AJAY TAX & CONSULTANCY
        </h1>

        <div className="flex gap-8 text-sm text-gray-300">
          <a href="#services" className="hover:text-green-400">Services</a>
          <a href="#about" className="hover:text-green-400">About</a>
          <a href="#contact" className="hover:text-green-400">Contact</a>
        </div>
      </div>

      {/* HERO */}
      <section className="relative grid md:grid-cols-2 items-center gap-12 px-10 py-32 max-w-7xl mx-auto">

        <motion.div variants={fadeUp} initial="hidden" animate="show">

          <h2 className="text-5xl md:text-7xl font-extrabold leading-tight bg-gradient-to-r from-green-400 via-emerald-300 to-green-200 text-transparent bg-clip-text">
            Professional Tax & Business Consultancy
          </h2>

          <p className="text-gray-400 mt-8 text-lg max-w-xl">
            Trusted taxation and financial consultancy services helping
            individuals, startups and businesses stay compliant and grow.
          </p>

          <div className="flex gap-4 mt-10">
            <Button className="bg-green-500 hover:bg-green-600 text-white px-8 py-6 text-lg rounded-xl shadow-xl">
              Book Consultation
            </Button>

            <Button variant="outline" className="px-8 py-6 text-lg rounded-xl">
              Call 7209776725
            </Button>
          </div>

          {/* animated stats */}
          <div className="flex gap-12 mt-14">
            <div>
              <h3 className="text-3xl font-bold text-green-400">{clients}+</h3>
              <p className="text-gray-400 text-sm">Happy Clients</p>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-green-400">10+</h3>
              <p className="text-gray-400 text-sm">Expert Services</p>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-green-400">5★</h3>
              <p className="text-gray-400 text-sm">Client Rating</p>
            </div>
          </div>

        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
        >
          <img
            src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=1400&auto=format&fit=crop"
            alt="consulting"
            className="rounded-3xl shadow-[0_0_90px_rgba(16,185,129,0.45)] border border-white/10"
          />
        </motion.div>

      </section>

      {/* SERVICES */}
      <section id="services" className="px-10 py-24 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16">Our Professional Services</h2>

        <div className="grid md:grid-cols-3 gap-10">

          {[{
            icon: <Calculator />,
            title: "Income Tax Filing",
            text: "ITR filing for individuals and businesses"
          },{
            icon: <FileText />,
            title: "GST Services",
            text: "GST registration and return filing"
          },{
            icon: <Building2 />,
            title: "Business Registration",
            text: "Company, LLP & MSME registration"
          },{
            icon: <CalendarCheck />,
            title: "Compliance",
            text: "Monthly tax compliance support"
          },{
            icon: <Users />,
            title: "Business Advisory",
            text: "Financial planning & tax strategies"
          },{
            icon: <Star />,
            title: "Tax Planning",
            text: "Strategic tax saving solutions"
          }].map((service, i) => (

            <motion.div
              key={i}
              whileHover={{ scale: 1.08, rotate: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl shadow-xl"
            >
              <Card className="bg-transparent border-none">
                <CardContent className="p-8 space-y-4">
                  <div className="text-green-400">{service.icon}</div>
                  <h3 className="text-xl font-semibold">{service.title}</h3>
                  <p className="text-gray-400 text-sm">{service.text}</p>
                </CardContent>
              </Card>
            </motion.div>

          ))}

        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="px-10 py-24 bg-black/40 text-center">
        <h2 className="text-4xl font-bold mb-6">About Our Consultancy</h2>
        <p className="max-w-3xl mx-auto text-gray-400">
          AJAY TAX & CONSULTANCY led by Ajay Kumar Gupta provides professional
          taxation, GST and business consultancy services helping businesses
          stay compliant and financially efficient.
        </p>
      </section>

      {/* CONTACT */}
      <section id="contact" className="px-10 py-24 max-w-5xl mx-auto">

        <h2 className="text-4xl font-bold text-center mb-12">Contact Our Experts</h2>

        <div className="grid md:grid-cols-2 gap-10">

          <div className="space-y-4 text-gray-300">
            <p>Kidwaipur Income Tax, Near Red Velvet Hotel, Patna 800004</p>

            <p className="flex items-center gap-2">
              <Phone size={18}/> 7209776725
            </p>

            <p className="flex items-center gap-2">
              <Mail size={18}/> ajaygupta1736.2009@gmail.com
            </p>

            <p>Office Hours: 10 AM – 8 PM</p>
          </div>

          <div className="bg-white/5 border border-white/10 p-8 rounded-2xl backdrop-blur-xl">
            <form className="space-y-4">
              <input placeholder="Name" className="w-full p-3 rounded-lg bg-black border border-white/10" />
              <input placeholder="Phone" className="w-full p-3 rounded-lg bg-black border border-white/10" />
              <textarea placeholder="Message" className="w-full p-3 rounded-lg bg-black border border-white/10" />

              <Button className="w-full bg-green-500 hover:bg-green-600">Send Inquiry</Button>
            </form>
          </div>

        </div>

      </section>

      {/* floating whatsapp */}
      <a
        href="https://wa.me/917209776725"
        target="_blank"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 p-4 rounded-full shadow-2xl"
      >
        <Phone />
      </a>

      {/* FOOTER */}
      <footer className="text-center text-gray-500 text-sm py-10 border-t border-white/10">
        © {new Date().getFullYear()} AJAY TAX & CONSULTANCY — All rights reserved
      </footer>

    </div>
  );
}
